#!/usr/bin/env bash
set -euo pipefail
PACOTE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP=/root/wolf-whatsapp
node "$PACOTE/base/auditoria/composicao.cjs" "$APP" --check
node "$PACOTE/qr/patch.cjs" "$APP" --check
node "$PACOTE/documentos/instalar-flexivel.cjs" "$APP" --check
node "$PACOTE/instalar.cjs" "$APP" --check
WOLF_BACKEND_DIR="$APP" node --test "$PACOTE/qr/test.cjs" "$PACOTE/documentos/flexivel.test.cjs" "$PACOTE/base/auditoria/test.cjs" "$PACOTE/retorno.test.cjs"
node --test "$PACOTE/bko-vero-runtime.test.cjs"
node "$PACOTE/base/auditoria/composicao.cjs" "$APP" --apply
node "$PACOTE/qr/patch.cjs" "$APP"
node "$PACOTE/documentos/instalar-flexivel.cjs" "$APP" --apply
node "$PACOTE/instalar.cjs" "$APP" --apply
node - "$APP" <<'NODE'
const fs=require('fs'),path=require('path'),p=path.join(process.argv[2],'src/routes/fluxos.js');let s=fs.readFileSync(p,'utf8');s=s.replace('Number(fluxo.id)===27','[27,28].includes(Number(fluxo.id))');fs.writeFileSync(p,s);
NODE
pm2 restart wolf-whatsapp
node "$PACOTE/ativar.cjs"
echo 'Extensão Vero instalada e vinculada ao canal VERO.'
